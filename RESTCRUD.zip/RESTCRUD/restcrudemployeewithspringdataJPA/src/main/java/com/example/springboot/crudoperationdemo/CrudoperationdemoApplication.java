package com.example.springboot.crudoperationdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudoperationdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudoperationdemoApplication.class, args);
		// http://localhost:8082/api/employees
		// http://localhost:8082/api/employees/1
	}

}
