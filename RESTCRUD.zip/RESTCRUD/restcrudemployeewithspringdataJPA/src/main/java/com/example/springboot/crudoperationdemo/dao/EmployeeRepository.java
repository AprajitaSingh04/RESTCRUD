package com.example.springboot.crudoperationdemo.dao;

import com.example.springboot.crudoperationdemo.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> // entity type - employee and primary key is based on integer type
{
    // that's it..no needto writeany code


}
