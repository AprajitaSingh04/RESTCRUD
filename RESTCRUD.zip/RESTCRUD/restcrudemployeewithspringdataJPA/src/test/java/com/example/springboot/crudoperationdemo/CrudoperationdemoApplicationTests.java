package com.example.springboot.crudoperationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudoperationdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
